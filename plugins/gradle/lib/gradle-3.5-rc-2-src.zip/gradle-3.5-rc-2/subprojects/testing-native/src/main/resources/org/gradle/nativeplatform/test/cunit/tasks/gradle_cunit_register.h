/*
 * Called by the Gradle CUnit launcher to register all CUnit tests.
 */
void gradle_cunit_register();
